"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegisterRequestSchema = exports.LoginRequestSchema = void 0;
var login_request_1 = require("./login-request");
Object.defineProperty(exports, "LoginRequestSchema", { enumerable: true, get: function () { return login_request_1.LoginRequestSchema; } });
var register_request_1 = require("./register-request");
Object.defineProperty(exports, "RegisterRequestSchema", { enumerable: true, get: function () { return register_request_1.RegisterRequestSchema; } });
