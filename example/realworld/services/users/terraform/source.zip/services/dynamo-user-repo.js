"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildDynamoUserRepo = void 0;
const funamots_1 = require("funamots");
const userHashKey = (id) => `USER#${id}`;
const userRangeKey = () => `#USER#`;
const userKey = (userId) => ({
    hash: userHashKey(userId),
    range: userRangeKey(),
});
const userDto = (user) => ({
    ...userKey(user.id),
    gsi1Hash: user.email,
    gsi2Hash: user.username,
    data: user,
});
const eventDto = (e) => ({
    hash: `EVENT#${e.eventId}`,
    range: "EVENT",
    data: e,
});
const buildDynamoUserRepo = (tableName, client) => {
    const table = (0, funamots_1.tableBuilder)(tableName)
        .withKey("hash", "range")
        .withGlobalIndex("gsi1", "gsi1Hash", "range")
        .withGlobalIndex("gsi2", "gsi2Hash", "range")
        .build({ client });
    const putUser = (user) => table.put(userDto(user));
    const putEvent = (event) => table.put(eventDto(event));
    return {
        transactionally: async (handler) => {
            const dtos = [];
            await handler({
                putEvent: (e) => dtos.push(eventDto(e)),
                putUser: (u) => dtos.push(userDto(u)),
            });
            await table.transactPut(dtos.map((d) => ({
                item: d,
            })));
        },
        getUser: (id) => table.get(userKey(id)).then((r) => r?.data),
        getUserByEmail: (email) => table.indexes.gsi1
            .query(email)
            .then((r) => r.records.length > 0 ? r.records[0].data : undefined),
        getUserByUsername: (username) => table.indexes.gsi2
            .query(username)
            .then((r) => r.records.length > 0 ? r.records[0].data : undefined),
    };
};
exports.buildDynamoUserRepo = buildDynamoUserRepo;
