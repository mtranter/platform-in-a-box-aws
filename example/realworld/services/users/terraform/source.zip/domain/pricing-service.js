"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildPricingService = void 0;
const discount_strategy_1 = require("./discount-strategy");
const buildPricingService = (repo) => ({
    getItemPrice: async (sku, count) => {
        const strategyP = repo.getItemPricingStrategy(sku);
        const rrpP = repo.getItemRRP(sku);
        const [strategy, rrp] = await Promise.all([strategyP, rrpP]);
        if (!strategy || !rrp) {
            return undefined;
        }
        return discount_strategy_1.DiscountStrategyContext.calculateDiscount({ unitRrp: rrp, count, sku }, strategy);
    },
});
exports.buildPricingService = buildPricingService;
