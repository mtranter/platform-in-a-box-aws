"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginRequestSchema = void 0;
const typebox_1 = require("@sinclair/typebox");
exports.LoginRequestSchema = typebox_1.Type.Object({
    email: typebox_1.Type.String(),
    password: typebox_1.Type.String(),
});
