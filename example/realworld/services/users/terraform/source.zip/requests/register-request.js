"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegisterRequestSchema = void 0;
const typebox_1 = require("@sinclair/typebox");
exports.RegisterRequestSchema = typebox_1.Type.Object({
    username: typebox_1.Type.String({ minLength: 4, maxLength: 64 }),
    email: typebox_1.Type.String({
        pattern: '^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$'
    }),
    password: typebox_1.Type.String({ minLength: 8 })
});
