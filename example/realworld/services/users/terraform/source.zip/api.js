"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.buildApi = void 0;
const aws_sdk_1 = require("aws-sdk");
const ts_lambda_router_1 = require("ts-lambda-router");
const aws_xray_sdk_core_1 = __importDefault(require("aws-xray-sdk-core"));
const domain_1 = require("./domain");
const dynamo_pricing_repo_1 = require("./services/dynamo-pricing-repo");
const buildApi = (svc) => ts_lambda_router_1.LambdaRouter.build((r) => r.get("/item/{sku:string}/price?{count?:int}")(async (req) => {
    const price = await svc.getItemPrice(req.pathParams.sku, req.queryParams.count ?? 1);
    return price
        ? req.response(200, price)
        : req.response(404, "Price not found");
}));
exports.buildApi = buildApi;
exports.handler = (0, exports.buildApi)((0, domain_1.buildPricingService)((0, dynamo_pricing_repo_1.buildDynamoPricingRepo)(process.env.DYNAMODB_TABLE_NAME, aws_xray_sdk_core_1.default.captureAWSClient(new aws_sdk_1.DynamoDB()))));
