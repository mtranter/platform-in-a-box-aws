"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildDynamoPricingRepo = void 0;
const funamots_1 = require("funamots");
const buildDynamoPricingRepo = (tableName, client) => {
    const table = (0, funamots_1.tableBuilder)(tableName)
        .withKey("hash", "range")
        .build({ client });
    const discountStrategyHashKey = (sku) => `DISCOUNT_STRATEGY#${sku}`;
    const discountStrategyRangeKey = (s) => `#METADATA#${s.type}`;
    const discountStrategyKey = (sku, s) => ({
        hash: discountStrategyHashKey(sku),
        range: discountStrategyRangeKey(s),
    });
    const rrpHashKey = (sku) => `RRP#${sku}`;
    const rrpRangeKey = "#METADATA#";
    const rrpKey = (sku) => ({
        hash: rrpHashKey(sku),
        range: rrpRangeKey,
    });
    return {
        putItemPricingStrategy: (sku, strategy) => table.put({
            ...discountStrategyKey(sku, strategy),
            data: strategy,
        }),
        getItemPricingStrategy: (sku) => table
            .query(discountStrategyHashKey(sku))
            .then((r) => r.records.map((dto) => dto.data)),
        putItemRRP: (sku, rrp) => table.put({
            ...rrpKey(sku),
            data: {
                rrp,
            },
        }),
        getItemRRP: (sku) => table.get(rrpKey(sku)).then((r) => r?.data?.rrp),
    };
};
exports.buildDynamoPricingRepo = buildDynamoPricingRepo;
