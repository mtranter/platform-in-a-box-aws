"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.priceResult = void 0;
const priceResult = (sku, count, rrp, discount) => ({
    sku,
    count,
    subTotal: rrp * count,
    total: rrp * count - (discount?.amount ?? 0),
    discount,
});
exports.priceResult = priceResult;
