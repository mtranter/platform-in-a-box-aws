"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildApi = void 0;
const ts_lambda_router_1 = require("ts-lambda-router");
const register_request_1 = require("./../requests/register-request");
const login_request_1 = require("./../requests/login-request");
const buildApi = (svc, jwt) => {
    const buildUserResponse = (u) => {
        const { passwordHash, ...safeUser } = u;
        const token = jwt.sign(safeUser);
        const { id, ...user } = u;
        return { bio: "", image: "", ...user, token };
    };
    return ts_lambda_router_1.LambdaRouter.build((r) => r
        .post("/register", register_request_1.RegisterRequestSchema, {})(async (req) => {
        const response = await svc.registerUser(req.body);
        return response === "UserExists"
            ? req.response(409, "User Exists")
            : req.response(201, buildUserResponse(response));
    })
        .post("/login", login_request_1.LoginRequestSchema)(async (req, orig) => {
        const user = await svc.loginUser(req.body);
        if (!user) {
            return req.response(401, "Unauthorized");
        }
        return req.response(200, buildUserResponse(user));
    })
        .get("/me")(async (req, orig) => {
        const jwtUser = await jwt.getUserFromHeader(orig);
        if (!jwtUser) {
            return req.response(401, "Unauthorized");
        }
        else {
            const user = await svc.getUser(jwtUser.id);
            return user
                ? req.response(200, user)
                : req.response(401, "Unauthorized");
        }
    }));
};
exports.buildApi = buildApi;
