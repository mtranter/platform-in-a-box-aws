"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscountStrategyContext = void 0;
const ts_pattern_1 = require("ts-pattern");
const price_result_1 = require("./price-result");
exports.DiscountStrategyContext = {
    calculateDiscount: (item, strategies) => strategies.reduce((p, s) => {
        return p.discount
            ? p
            : (0, ts_pattern_1.match)(s)
                .with({ type: "BuyXGetYFree" }, (bogof) => {
                const amount = item.count > bogof.x ? item.unitRrp * bogof.y : 0;
                return (0, price_result_1.priceResult)(item.sku, item.count, item.unitRrp, amount === 0
                    ? undefined
                    : {
                        amount,
                        description: `Buy ${bogof.x} get ${bogof.y} free`,
                    });
            })
                .with({ type: "OnSpecial" }, (s) => (0, price_result_1.priceResult)(item.sku, item.count, item.unitRrp, {
                amount: s.discount * (item.unitRrp * item.count),
                description: "On Special",
            }))
                .exhaustive();
    }, (0, price_result_1.priceResult)(item.sku, item.count, item.unitRrp)),
};
