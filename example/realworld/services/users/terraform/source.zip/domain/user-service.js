"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildUserService = void 0;
const uuidv4_1 = require("uuidv4");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const hashPassword = (password) => new Promise((res, rej) => bcryptjs_1.default.hash(password, 10, (e, p) => (e ? rej(e) : res(p))));
const validatePassword = (attempt, hash) => new Promise((res, rej) => bcryptjs_1.default.compare(attempt, hash, (err, ok) => (err ? rej(err) : res(ok))));
const buildUserService = (repo) => ({
    getUser: (id) => repo.getUser(id),
    loginUser: async (req) => {
        const user = await repo.getUserByEmail(req.email);
        if (!user) {
            return undefined;
        }
        const isValid = await validatePassword(req.password, user.passwordHash);
        return isValid ? user : undefined;
    },
    registerUser: async (req) => {
        const userByEmailP = repo.getUserByEmail(req.email);
        const userByUsernameP = repo.getUserByEmail(req.username);
        const [userByEmail, userByUsername] = await Promise.all([
            userByEmailP,
            userByUsernameP,
        ]);
        if (userByEmail || userByUsername) {
            return "UserExists";
        }
        const id = (0, uuidv4_1.uuid)();
        const { password, ...userParams } = { id, ...req };
        const passwordHash = await hashPassword(password);
        const user = { passwordHash, ...userParams };
        await repo.transactionally(async (tx) => {
            const { passwordHash, ...safeUser } = user;
            tx.putUser(user);
            tx.putEvent({
                eventId: (0, uuidv4_1.uuid)(),
                timestamp: new Date().toISOString(),
                event: { type: "UserCreated", newUser: safeUser },
            });
        });
        return user;
    },
});
exports.buildUserService = buildUserService;
