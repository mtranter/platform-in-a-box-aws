"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildJwt = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const buildJwt = (secret, _jwt = jsonwebtoken_1.default) => ({
    getUserFromHeader: async (orig) => {
        const authHeader = orig.originalEvent.headers['authorization'];
        const token = authHeader?.substring('Token '.length);
        if (!token) {
            return undefined;
        }
        try {
            return _jwt.verify(token, secret);
        }
        catch {
            return undefined;
        }
    },
    sign: (o) => _jwt.sign(o, secret)
});
exports.buildJwt = buildJwt;
